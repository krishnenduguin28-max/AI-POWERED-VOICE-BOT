from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import shutil

from asr.whisper_asr import transcribe_audio
from nlp.intent_predictor import predict_intent
from response.response_generator import generate_response
from tts.tts_engine import text_to_speech

app = FastAPI(title="AI Voicebot API")


class TextRequest(BaseModel):
    text: str


class IntentRequest(BaseModel):
    intent: str


# Speech to Text

@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):

    temp_audio = "temp_audio.wav"

    with open(temp_audio, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    text = transcribe_audio(temp_audio)

    return {"transcribed_text": text}


# Predict Intent

@app.post("/predict-intent")
def predict(request: TextRequest):

    intent, confidence = predict_intent(request.text)

    return {
        "intent": intent,
        "confidence": float(confidence)
    }


# Generate Response

@app.post("/generate-response")
def response(request: IntentRequest):

    reply = generate_response(request.intent)

    return {"response": reply}


# Text to Speech

@app.post("/synthesize")
def synthesize(request: TextRequest):

    audio_file = text_to_speech(request.text)

    return {"audio_file": audio_file}



# Full Voicebot Pipeline

@app.post("/voicebot")
async def voicebot(file: UploadFile = File(...)):

    temp_audio = "temp_audio.wav"

    with open(temp_audio, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Step 1: Speech to Text
    text = transcribe_audio(temp_audio)

    # Step 2: Intent Detection
    intent, confidence = predict_intent(text)

    # Step 3: Generate Response
    reply = generate_response(intent)

    # Step 4: Convert to Speech
    audio_output = text_to_speech(reply)

    return {
        "recognized_text": text,
        "intent": intent,
        "confidence": float(confidence),
        "response": reply,
        "audio_output": audio_output
    }
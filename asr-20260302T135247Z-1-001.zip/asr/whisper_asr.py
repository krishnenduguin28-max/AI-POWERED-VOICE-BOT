import whisper

# Load Whisper model
model = whisper.load_model("base")

def transcribe_audio(audio_path):
    
    result = model.transcribe(audio_path)
    
    text = result["text"]
    
    return text


if __name__ == "__main__":
    
    audio_file = "tests/sample_audio.wav"
    
    text = transcribe_audio(audio_file)
    
    print("Transcribed Text:")
    print(text)
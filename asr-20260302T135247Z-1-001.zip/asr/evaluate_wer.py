from jiwer import wer
from whisper_asr import transcribe_audio

# small evaluation dataset
test_samples = [
    ("tests/sample_audio.wav", "where is my order")
]

for audio_path, ground_truth in test_samples:

    predicted = transcribe_audio(audio_path)

    error = wer(ground_truth.lower(), predicted.lower())

    print("\nGround Truth:", ground_truth)
    print("Predicted:", predicted)
    print("Word Error Rate:", error)
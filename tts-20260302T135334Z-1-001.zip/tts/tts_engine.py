from gtts import gTTS
import os

def text_to_speech(text, output_file="response.mp3"):

    tts = gTTS(text=text, lang="en", slow=False)

    tts.save(output_file)

    return output_file


if __name__ == "__main__":

    sample_text = "Your order is currently being processed and will be delivered soon."

    output = text_to_speech(sample_text)

    print("Audio generated:", output)
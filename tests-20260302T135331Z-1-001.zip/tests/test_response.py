from response.response_generator import generate_response

intent = "order_status"

response = generate_response(intent)

print("Intent:", intent)
print("Response:", response)
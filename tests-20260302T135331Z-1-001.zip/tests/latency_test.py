import time

from asr.whisper_asr import transcribe_audio
from nlp.intent_predictor import predict_intent
from response.response_generator import generate_response
from tts.tts_engine import text_to_speech

audio_file = "tests/sample_audio.wav"

start = time.time()

# ASR
text = transcribe_audio(audio_file)

# Intent
intent, confidence = predict_intent(text)

# Response
reply = generate_response(intent)

# TTS
audio_output = text_to_speech(reply)

end = time.time()

latency = end - start

print("Recognized Text:", text)
print("Intent:", intent)
print("Response:", reply)
print("Audio Output:", audio_output)

print("\nTotal Latency:", round(latency,2), "seconds")
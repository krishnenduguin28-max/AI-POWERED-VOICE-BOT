import joblib
import numpy as np

# Load model and vectorizer
model = joblib.load("models/intent_model.pkl")
vectorizer = joblib.load("models/vectorizer.pkl")


def predict_intent(text):

    text_vec = vectorizer.transform([text])

    prediction = model.predict(text_vec)[0]

    probabilities = model.predict_proba(text_vec)

    confidence = np.max(probabilities)

    return prediction, confidence


if __name__ == "__main__":

    user_input = input("Enter your query: ")

    intent, confidence = predict_intent(user_input)

    print("\nPredicted Intent:", intent)
    print("Confidence:", round(confidence, 2))
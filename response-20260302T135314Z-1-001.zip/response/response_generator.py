responses = {

    "order_status": "Your order is currently being processed and will be delivered soon.",

    "cancel_order": "Your order cancellation request has been received and will be processed shortly.",

    "refund_request": "Your refund request has been initiated. The amount will be returned within 5 to 7 business days.",

    "payment_issue": "It seems there was an issue with your payment. Please try again or use another payment method.",

    "subscription_issue": "Your subscription request has been processed. If you need further assistance, please contact support.",

    "delivery_delay": "We apologize for the delay. Your delivery is on the way and should arrive soon.",

    "account_help": "It seems you are having trouble accessing your account. Please try resetting your password.",

    "product_information": "You can find detailed product information on the product page including features and specifications.",

    "change_address": "Your request to update the delivery address has been received and will be updated shortly.",

    "complaint": "We are sorry for the inconvenience. Your complaint has been recorded and our team will review it."
}


def generate_response(intent):

    if intent in responses:
        return responses[intent]

    return "I'm sorry, I couldn't understand your request. Please try again."